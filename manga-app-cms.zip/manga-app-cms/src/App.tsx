import React, { useEffect, useState } from 'react';

const App: React.FC = () => {
  const [data, setData] = useState<string>('');

  useEffect(() => {
    fetch('/api')
        .then(response => response.text())
        .then(text => setData(text));
  }, []);

  return (
      <div>
        <h1>{data}</h1>
      </div>
  );
};

export default App;

