export default function Carousel() {
    return(
        <>
            <section className="carousel section">
                <h2>Популярні Манги</h2>
                <div className="carousel-container">
                    <div className="manga-card">Манга 1</div>
                    <div className="manga-card">Манга 2</div>
                    <div className="manga-card">Манга 3</div>
                </div>
            </section>
        </>
    )
}