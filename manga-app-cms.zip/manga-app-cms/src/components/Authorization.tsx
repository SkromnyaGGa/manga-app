import React, { useState } from 'react';
import './auth.css';
import axios from 'axios';

interface AuthorizationProps {
    onClose: () => void;
}

const Authorization: React.FC<AuthorizationProps> = ({ onClose }) => {
    const [rightPanelActive, setRightPanelActive] = useState(false);

    const handleSignInClick = () => {
        setRightPanelActive(false);
    };

    const handleSignUpClick = () => {
        setRightPanelActive(true);
    };

    const [nickname, setNickname] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
        e.preventDefault();

        // Input validation logic here (if any)

        const endpoint = rightPanelActive ? "http://localhost:3000/register" : "http://localhost:3000/login";
        const data = rightPanelActive ? { nickname, email, password } : { email, password };

        try {
            const res = await axios.post(endpoint, data);
            if (res.data === "success") {
                onClose();
            } else {
                onClose();
            }
        } catch (error) {
            console.error(error);
            alert("An error occurred. Please try again.");
        }
    }

    return (
        <>
            <div className="auth-modal">
                <div className={`container ${rightPanelActive ? 'right-panel-active' : ''}`} id="container">
                    <div className="form-container sign-up-container">
                        <form onSubmit={handleSubmit}>
                            <h1>Створити аккаунт</h1>
                            <span>Використай свою електронну адресу для реєстрації</span>
                            <input type="text" onChange={(e) => { setNickname(e.target.value) }} placeholder="Нікнейм"/>
                            <input type="email" onChange={(e) => { setEmail(e.target.value) }} placeholder="Електронна пошта"/>
                            <input type="password" onChange={(e) => { setPassword(e.target.value) }} placeholder="Пароль"/>
                            <button type="submit">Зарегеструватися</button>
                        </form>
                    </div>
                    <div className="form-container sign-in-container">
                        <form onSubmit={handleSubmit}>
                            <h1>Увійти</h1>
                            <input type="email" onChange={(e) => { setEmail(e.target.value) }} placeholder="Пошта"/>
                            <input type="password" onChange={(e) => { setPassword(e.target.value) }} placeholder="Пароль"/>
                            <a href="#">Забув свій пароль?</a>
                            <button type="submit">Увійти</button>
                        </form>
                    </div>
                    <div className="overlay-container">
                        <div className="overlay">
                            <div className="overlay-panel overlay-left">
                                <h1>Знову привіт!</h1>
                                <p>Авторизуйся, чтоб слідкувати за мангою</p>
                                <button className="ghost" id="signIn" onClick={handleSignInClick}>Увійти</button>
                            </div>
                            <div className="overlay-panel overlay-right">
                                <h1>Привіт, друже!</h1>
                                <p>Впиши дані для реєстрації, щоб увійти до нашої сім'ї</p>
                                <button className="ghost" id="signUp" onClick={handleSignUpClick}>Зареструватися</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="auth-backdrop" onClick={onClose}></div>
        </>
    );
};

export default Authorization;
