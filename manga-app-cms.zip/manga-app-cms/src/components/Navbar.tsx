import { useState } from "react";
import Authorization from "./Authorization";

export default function Navbar() {
    const [showAuth, setShowAuth] = useState(false);

    const handleAuthClick = () => {
        setShowAuth(true);
    };

    const closeAuthModal = () => {
        setShowAuth(false);
    };

    return (
        <>
            <nav className="navbar">
                <div className="navbar-container">
                    <div className="logo">Лого</div>
                    <div className="search-container">
                        <label>
                            <input type="text" placeholder="Пошук манги..." className="search-bar"/>
                        </label>
                        <button className="search-btn"><img src="icons/search.png" alt={'Пошук'}></img></button>
                    </div>
                    <div className="nav-links">
                        <button className="random-btn">Рандомна Манга</button>
                        <button className="auth-btn" onClick={handleAuthClick}>Вхід / Реєстрація</button>
                        {showAuth && <Authorization onClose={closeAuthModal} />}
                    </div>
                </div>
            </nav>
        </>
    );
}
