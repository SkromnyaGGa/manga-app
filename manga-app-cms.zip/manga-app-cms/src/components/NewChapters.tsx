export default function NewChapters() {
    return (
        <>
            <section className="new-chapters section">
                <h2>Нові Глави</h2>
                <ul className="chapter-list">
                    <li className="chapter-item">Манга 1 - Глава 10</li>
                    <li className="chapter-item">Манга 2 - Глава 5</li>
                    <li className="chapter-item">Манга 3 - Глава 22</li>
                </ul>
            </section>
        </>
    )
}