export default function LastNews() {
    return(
        <>
            <section className="news section">
                <h2>Останні Новини</h2>
                <div className="news-item">Новина 1</div>
                <div className="news-item">Новина 2</div>
                <div className="news-item">Новина 3</div>
            </section>
        </>
    )
}