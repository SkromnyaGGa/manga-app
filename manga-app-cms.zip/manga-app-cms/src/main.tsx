import React from 'react'
import ReactDOM from 'react-dom/client'
import Navbar from "./components/Navbar.tsx";
import './index.css'
import Carousel from "./components/Carousel.tsx";
import LastNews from "./components/LastNews.tsx";
import NewChapters from "./components/NewChapters.tsx";

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <Navbar />
      <main>
          <Carousel />
          <LastNews />
          <NewChapters />
      </main>
  </React.StrictMode>,
)
