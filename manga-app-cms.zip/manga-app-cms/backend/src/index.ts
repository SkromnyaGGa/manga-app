import express, { Request, Response } from "express";
import cors from "cors";
import { MongoClient, Collection } from "mongodb";

const app = express();
const port = 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());

// Підключення до MongoDB
const url = 'mongodb://localhost:27017'; // ваш MongoDB URL
const dbName = 'manga-app'; // назва вашої бази даних
let collection: Collection;

MongoClient.connect(url)
    .then(client => {
        const db = client.db(dbName);
        collection = db.collection('Users'); // назва вашої колекції
        console.log("Connected successfully to MongoDB");
    })
    .catch(err => console.error(err));

// Route handlers
app.get("/", cors(), (req: Request, res: Response) => {
    res.send("Hello World");
});

app.post("/check-user", async (req: Request, res: Response) => {
    const { nickname, email } = req.body;

    try {
        const check = await collection.findOne({ nickname, email });

        if (check) {
            res.json("exist");
        } else {
            res.json("notexist");
        }
    } catch (e) {
        res.json("fail");
    }
});

// Register endpoint
app.post("/register", async (req: Request, res: Response) => {
    const { nickname, email, password } = req.body;

    try {
        const existingUser = await collection.findOne({ email });
        if (existingUser) {
            res.json("exist");
        } else {
            await collection.insertOne({ nickname, email, password });
            res.json("success");
        }
    } catch (e) {
        res.json("fail");
    }
});

// Login endpoint
app.post("/login", async (req: Request, res: Response) => {
    const { email, password } = req.body;

    try {
        const user = await collection.findOne({ email });
        if (user && user.password === password) { // This is a simplistic check; use hashed passwords in production
            res.json("success");
        } else {
            res.json("fail");
        }
    } catch (e) {
        res.json("error");
    }
});

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});


